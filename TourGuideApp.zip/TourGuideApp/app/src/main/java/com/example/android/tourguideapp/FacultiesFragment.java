package com.example.android.tourguideapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.support.v4.app.Fragment;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class FacultiesFragment extends Fragment{
    public FacultiesFragment () {
    }
    public static android.support.v4.app.Fragment newInstance () {
        android.support.v4.app.Fragment fragment = new android.support.v4.app.Fragment();
       return fragment;
    }

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.result_list, container, false);

        final ArrayList<Result> result = new ArrayList<Result>();
        result.add(new Result(R.string.fsega_faculty, R.string.fsega_address, R.string.fsega_contact, R.drawable.f1));
        result.add(new Result(R.string.umf_faculty, R.string.umf_address, R.string.umf_contact, R.drawable.f2));
        result.add(new Result(R.string.psychology_faculty, R.string.psychology_address, R.string.psychology_contact, R.drawable.f3));
        result.add(new Result(R.string.tv_faculty, R.string.tv_address, R.string.tv_contact, R.drawable.f4));
        result.add(new Result(R.string.geo_faculty, R.string.geo_address, R.string.geo_contact, R.drawable.f5));

        ResultAdapter adapter = new ResultAdapter(getActivity(), result, R.color.categoryFaculties);

        ListView listView = (ListView) rootView.findViewById(R.id.result_list);

        listView.setAdapter(adapter);

        return rootView;
    }
}


package com.example.android.tourguideapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class MonumentsFragment extends Fragment {
    public MonumentsFragment() {
    }

    public static MonumentsFragment newInstance(){
        MonumentsFragment fragment = new MonumentsFragment();
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.result_list, container, false);

        final ArrayList<Result> result = new ArrayList<Result>();
        result.add(new Result(R.string.matia_monument, R.string.matia_address, R.string.matia_contact, R.drawable.mo1));
        result.add(new Result(R.string.bastion_monument, R.string.bastion_address, R.string.bastion_contact, R.drawable.mo2));
        result.add(new Result(R.string.george_monument, R.string.george_address, R.string.george_contact, R.drawable.mo3));
        result.add(new Result(R.string.rooster_monument, R.string.rooster_address, R.string.rooster_contact, R.drawable.mo4));
        result.add(new Result(R.string.palace_monument, R.string.palace_address, R.string.palace_contact, R.drawable.mo5));

        ResultAdapter adapter = new ResultAdapter(getActivity(), result, R.color.categoryMonuments);

        ListView listView = (ListView) rootView.findViewById(R.id.result_list);

        listView.setAdapter(adapter);

        return rootView;
    }

}

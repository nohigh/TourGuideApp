package com.example.android.tourguideapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

class MuseumsFragment extends Fragment {
    public MuseumsFragment() {
    }

    public static MuseumsFragment newInstance(){
        MuseumsFragment fragment = new MuseumsFragment();
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.result_list, container, false);

        final ArrayList<Result> result = new ArrayList<Result>();
        result.add(new Result(R.string.emil_museum, R.string.emil_address, R.string.emil_contact, R.drawable.mu));
        result.add(new Result(R.string.pharmacy_museum, R.string.pharmacy_address, R.string.pharmacy_contact, R.drawable.mu2));
        result.add(new Result(R.string.national_museum, R.string.national_address, R.string.national_contact, R.drawable.mu3));
        result.add(new Result(R.string.zoo_museum, R.string.zoo_address, R.string.zoo_contact, R.drawable.mu4));
        result.add(new Result(R.string.banffy_museum, R.string.banffy_address, R.string.banffy_contact, R.drawable.mu5));

        ResultAdapter adapter = new ResultAdapter(getActivity(), result, R.color.categoryMuseums);

        ListView listView = (ListView) rootView.findViewById(R.id.result_list);

        listView.setAdapter(adapter);

        return rootView;
    }
}

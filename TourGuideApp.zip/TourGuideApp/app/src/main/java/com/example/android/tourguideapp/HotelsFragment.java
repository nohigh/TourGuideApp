package com.example.android.tourguideapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class HotelsFragment extends Fragment {
    public HotelsFragment() {
    }

    public static HotelsFragment newInstance(){
        HotelsFragment fragment = new HotelsFragment();
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.result_list, container, false);

        final ArrayList<Result> result = new ArrayList<Result>();
        result.add(new Result(R.string.grand_hotel, R.string.grand_address, R.string.grand_contact, R.drawable.dr1));
        result.add(new Result(R.string.golden_hotel, R.string.golden_address, R.string.golden_contact, R.drawable.dr2));
        result.add(new Result(R.string.italia_hotel, R.string.italia_address, R.string.italia_contact, R.drawable.dr3));
        result.add(new Result(R.string.west_hotel, R.string.west_address, R.string.west_contact, R.drawable.d4));
        result.add(new Result(R.string.beyfin_hotel, R.string.beyfin_address, R.string.beyfin_contact, R.drawable.dr5));

        ResultAdapter adapter = new ResultAdapter(getActivity(), result, R.color.categoryHotels);

        ListView listView = (ListView) rootView.findViewById(R.id.result_list);

        listView.setAdapter(adapter);

        return rootView;

    }
}
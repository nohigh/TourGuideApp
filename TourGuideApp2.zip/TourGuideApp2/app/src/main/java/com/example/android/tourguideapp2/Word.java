package com.example.android.tourguideapp2;

public class Word {

    // Store the id of the image
    private int mImageDrawable;
    // Store the name of the object
    private String mName;
    //Store the adress of the object
    private String mAdress;

    // Constructor that is used to create an instance of the Word object
    public Word(int mImageDrawable, String mName, String mAdress) {
        this.mImageDrawable = mImageDrawable;
        this.mName = mName;
        this.mAdress = mAdress;
    }

    public int getmImageDrawable() {
        return mImageDrawable;
    }

    public void setmImageDrawable(int mImageDrawable) {
        this.mImageDrawable = mImageDrawable;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getmAdress() {
        return mAdress;
    }

    public void setmAdress(String mAdress) {
        this.mAdress = mAdress;
    }

}
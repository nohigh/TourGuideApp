package com.example.android.tourguideapp2;

import android.graphics.Movie;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class FragmentHotel extends Fragment {
    View view;

    public FragmentHotel() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle SavedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

// Create a list of words
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word(R.drawable.dr1, getString(R.string.grand_hotel), getString(R.string.grand_address)));
        words.add(new Word(R.drawable.dr2, getString(R.string.golden_hotel), getString(R.string.golden_address)));
        words.add(new Word(R.drawable.dr3, getString(R.string.italia_hotel), getString(R.string.italia_address)));
        words.add(new Word(R.drawable.d4, getString(R.string.west_hotel), getString(R.string.west_address)));
        words.add(new Word(R.drawable.dr5, getString(R.string.beyfin_hotel), getString(R.string.beyfin_address)));


        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        WordAdapter adapter = new WordAdapter(getActivity(), words);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml layout file.

        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);
        return rootView;
    }
}

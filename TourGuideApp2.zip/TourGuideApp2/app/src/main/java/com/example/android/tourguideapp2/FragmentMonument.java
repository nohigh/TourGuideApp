package com.example.android.tourguideapp2;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class FragmentMonument extends Fragment {
    View view;

    public FragmentMonument() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        // Create a list of words
        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word(R.drawable.mo1, getString(R.string.matia_monument), getString(R.string.matia_address)));
        words.add(new Word(R.drawable.mo2, getString(R.string.bastion_monument), getString(R.string.bastion_address)));
        words.add(new Word(R.drawable.mo3, getString(R.string.george_monument), getString(R.string.george_address)));
        words.add(new Word(R.drawable.mo4, getString(R.string.rooster_monument), getString(R.string.rooster_address)));
        words.add(new Word(R.drawable.mo5, getString(R.string.palace_monument), getString(R.string.palace_address)));


        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        WordAdapter adapter = new WordAdapter(getActivity(), words);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml layout file.

        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);


        return rootView;
    }
}

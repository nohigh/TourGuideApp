package com.example.android.bookinventory;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.bookinventory.data.BookContract;


public class BookCursorAdapter extends CursorAdapter {

    public BookCursorAdapter(Context context, Cursor c) {
        super(context, c, 0 /* flags */);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
    }

    @Override
    public void bindView(View view, final Context context, Cursor cursor) {

        // find individual views
        ImageView bookImage = (ImageView) view.findViewById(R.id.list_item_book_image_view);
        TextView nameTextView = (TextView) view.findViewById(R.id.name_text_view);
        TextView priceTextView = (TextView) view.findViewById(R.id.price_text_view);
        TextView quantityTextView = (TextView) view.findViewById(R.id.quantity_text_view);
        ImageView saleImage = (ImageView) view.findViewById(R.id.list_item_sale_image_view);

        // find columns of books attributes needed
        int idColumnIndex = cursor.getColumnIndex(BookContract.BookEntry._ID);
        int photoColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_PHOTO);
        int nameColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_NAME);
        int priceColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_PRICE);
        int quantityColumnIndex = cursor.getColumnIndex(BookContract.BookEntry.COLUMN_BOOK_QUANTITY);

        // read book attributes from the cursor for current book
        final int bookId = cursor.getInt(idColumnIndex);
        byte[] bookPhoto = cursor.getBlob(photoColumnIndex);
        String bookName = cursor.getString(nameColumnIndex);
        int bookPrice = cursor.getInt(priceColumnIndex);
        final int bookQuantity = cursor.getInt(quantityColumnIndex);

        // update views with the attributes for the current book
        Bitmap bookBitmap = BitmapFactory.decodeByteArray(bookPhoto, 0, bookPhoto.length);
        bookImage.setImageBitmap(bookBitmap);
        nameTextView.setText(bookName);
        priceTextView.setText("€" + Integer.toString(bookPrice));
        quantityTextView.setText(Integer.toString(bookQuantity));

        saleImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri currentBookUri = ContentUris.withAppendedId(BookContract.BookEntry.CONTENT_URI, bookId);
                makeSale(context, bookQuantity, currentBookUri);
            }
        });
    }

    private void makeSale(Context context, int bookQuantity, Uri uriBook) {
        if (bookQuantity == 0) {
            Toast.makeText(context, R.string.no_book_to_sell, Toast.LENGTH_SHORT).show();
        } else {
            int newQuantity = bookQuantity - 1;
            ContentValues values = new ContentValues();
            values.put(BookContract.BookEntry.COLUMN_BOOK_QUANTITY, newQuantity);
            context.getContentResolver().update(uriBook, values, null, null);
        }
    }
}